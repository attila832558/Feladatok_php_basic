<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Default(1.feladat)</title>
</head>
<body>
        <?php
    echo "Az első PHP Scriptem!"
        ?>
</body>
</html>